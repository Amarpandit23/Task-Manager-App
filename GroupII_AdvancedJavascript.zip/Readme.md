GROUP PROJECT - ADVANCED JAVASCRIPT

SECTION 6 - GROUP II

GROUP MEMBERS:

1 - Poojan Pradhan (8958434)
2 - Amar Pandit (8964045)
3 - Nikhilesh Raut (8998293)

GROUP CONTRIBUTIONS:

Poojan - Responsible for leading the entire project from start to finish.

Nikhilesh - Helped in custom styling components, and finding reference for similar projects to study.

Amar Pandit - Come up with functionalities of Add Task
