// GROUP II - TMA - Poojan,Nikhilesh & Amar

// Selectors
const addTaskBtn = document.getElementById("add-task-btn");
const modal = document.getElementById("task-modal");
const closeBtn = document.querySelector(".close-btn");
const taskForm = document.getElementById("task-form");
const taskInput = document.querySelector(".task-input");
const taskDescription = document.querySelector(".task-description");
const taskPriority = document.querySelector(".task-priority");
const taskAssignedTo = document.querySelector(".task-assigned-to");
const taskDeadline = document.querySelector(".task-deadline");
const taskList = document.querySelector(".task-list");
const standardTheme = document.querySelector(".standard-theme");
const lightTheme = document.querySelector(".light-theme");
const darkerTheme = document.querySelector(".darker-theme");
const searchBar = document.getElementById("search-bar");
const numberItems = document.getElementById("number-items");

let isEditing = false;
let currentTaskElement = null;
let tasks = []; // Array to store tasks

// Event Listeners
addTaskBtn.addEventListener("click", openModal);
closeBtn.addEventListener("click", closeModal);
window.addEventListener("click", outsideClick);
taskForm.addEventListener("submit", addTask);
taskList.addEventListener("click", manageTask);
document.addEventListener("DOMContentLoaded", getTasks);
standardTheme.addEventListener("click", () => changeTheme("standard"));
lightTheme.addEventListener("click", () => changeTheme("light"));
darkerTheme.addEventListener("click", () => changeTheme("darker"));
searchBar.addEventListener("input", filterTasks); // Event listener for filtering tasks

// Check if a theme has been set previously and apply it (or std theme if not found)
let savedTheme = localStorage.getItem("savedTheme");
savedTheme === null ? changeTheme("standard") : changeTheme(savedTheme);

/**
 * Opens the modal dialog for adding or editing a task.
 */
function openModal() {
  modal.style.display = "flex";
  // Change button text if editing
  if (isEditing) {
    addTaskBtn.textContent = "Update Task";
  }
}

/**
 * Closes the modal dialog.
 */
function closeModal() {
  modal.style.display = "none";
  resetForm();
}

/**
 * Closes the modal dialog if clicked outside the modal.
 * @param {Event} e - The click event object.
 */
function outsideClick(e) {
  if (e.target === modal) {
    modal.style.display = "none";
    resetForm();
  }
}

/**
 * Adds a new task to the task list or updates an existing task if in edit mode.
 * @param {Event} event - The form submit event object.
 */
function addTask(event) {
  event.preventDefault();

  const taskTitle = taskInput.value;
  const taskDesc = taskDescription.value;
  const taskPrio = taskPriority.value;
  const taskAssign = taskAssignedTo.value;
  const taskDead = taskDeadline.value;

  if (isEditing) {
    updateTask(
      currentTaskElement,
      taskTitle,
      taskDesc,
      taskPrio,
      taskAssign,
      taskDead
    );
  } else {
    const newRow = document.createElement("tr");

    newRow.innerHTML = `
      <td>${taskTitle}</td>
      <td>${taskDesc}</td>
      <td>${taskPrio}</td>
      <td>${taskAssign}</td>
      <td>${taskDead}</td>
      <td>
        <button class="edit-btn ${savedTheme}-button">Edit</button>
        <button class="delete-btn ${savedTheme}-button">Delete</button>
      </td>
    `;

    taskList.appendChild(newRow);

    saveLocalTasks({
      title: taskTitle,
      description: taskDesc,
      priority: taskPrio,
      assignedTo: taskAssign,
      deadline: taskDead,
    });
  }

  resetForm();
  closeModal();
  resetTaskNumber(tasks);
  setColors();
}

/**
 * Updates an existing task in the task list.
 * @param {HTMLElement} taskElement - The HTML element representing the task row.
 * @param {string} taskTitle - The updated task title.
 * @param {string} taskDesc - The updated task description.
 * @param {string} taskPrio - The updated task priority.
 * @param {string} taskAssign - The updated task assigned-to.
 * @param {string} taskDead - The updated task deadline.
 */
function updateTask(
  taskElement,
  taskTitle,
  taskDesc,
  taskPrio,
  taskAssign,
  taskDead
) {
  taskElement.children[0].textContent = taskTitle;
  taskElement.children[1].textContent = taskDesc;
  taskElement.children[2].textContent = taskPrio;
  taskElement.children[3].textContent = taskAssign;
  taskElement.children[4].textContent = taskDead;

  updateLocalTasks(taskElement);
}

/**
 * Manages user actions on tasks (e.g., delete or edit).
 * @param {Event} event - The click event object.
 */
function manageTask(event) {
  const item = event.target;

  if (item.classList.contains("delete-btn")) {
    item.parentElement.parentElement.remove();
    removeLocalTasks(item.parentElement.parentElement);
  }

  if (item.classList.contains("edit-btn")) {
    editTask(item.parentElement.parentElement);
  }
}

/**
 * Prepares the modal for editing an existing task.
 * @param {HTMLElement} taskElement - The HTML element representing the task row.
 */
function editTask(taskElement) {
  const cells = taskElement.getElementsByTagName("td");
  const taskTitle = cells[0].textContent;
  const taskDesc = cells[1].textContent;
  const taskPrio = cells[2].textContent;
  const taskAssign = cells[3].textContent;
  const taskDead = cells[4].textContent;

  // Fill the modal with current task details for editing
  taskInput.value = taskTitle;
  taskDescription.value = taskDesc;
  taskPriority.value = taskPrio;
  taskAssignedTo.value = taskAssign;
  taskDeadline.value = taskDead;

  // Display the modal for editing
  modal.style.display = "flex";

  // Set the editing flag and current task element
  isEditing = true;
  currentTaskElement = taskElement;

  // Change button text to "Update Task"
  addTaskBtn.textContent = "Update Task";
}

/**
 * Saves a new task to local storage.
 * @param {Object} task - The task object containing title, description, priority, assignedTo, and deadline.
 */
function saveLocalTasks(task) {
  if (localStorage.getItem("tasks") === null) {
    tasks = [];
  } else {
    tasks = JSON.parse(localStorage.getItem("tasks"));
  }
  tasks.push(task);
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

/**
 * Retrieves tasks from local storage and displays them in the task list.
 */
function getTasks() {
  if (localStorage.getItem("tasks") === null) {
    tasks = [];
  } else {
    tasks = JSON.parse(localStorage.getItem("tasks"));
  }

  tasks.forEach(function (task) {
    const newRow = document.createElement("tr");

    newRow.innerHTML = `
      <td>${task.title}</td>
      <td>${task.description}</td>
      <td>${task.priority}</td>
      <td>${task.assignedTo}</td>
      <td>${task.deadline}</td>
      <td>
        <button class="edit-btn ${savedTheme}-button">Edit</button>
        <button class="delete-btn ${savedTheme}-button">Delete</button>
      </td>
    `;

    taskList.appendChild(newRow);
  });
  resetTaskNumber(tasks);
  setColors();
}

/**
 * Removes a task from local storage.
 * @param {HTMLElement} taskElement - The HTML element representing the task row to be removed.
 */
function removeLocalTasks(taskElement) {
  if (localStorage.getItem("tasks") === null) {
    tasks = [];
  } else {
    tasks = JSON.parse(localStorage.getItem("tasks"));
  }

  const taskTitle = taskElement.children[0].textContent;
  tasks = tasks.filter((task) => task.title !== taskTitle);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  resetTaskNumber(tasks);
  setColors();
}

/**
 * Updates an existing task in local storage.
 * @param {HTMLElement} taskElement - The HTML element representing the task row to be updated.
 */
function updateLocalTasks(taskElement) {
  if (localStorage.getItem("tasks") === null) {
    tasks = [];
  } else {
    tasks = JSON.parse(localStorage.getItem("tasks"));
  }

  const taskTitle = taskElement.children[0].textContent;
  const taskIndex = tasks.findIndex((task) => task.title === taskTitle);

  if (taskIndex !== -1) {
    tasks[taskIndex] = {
      title: taskTitle,
      description: taskElement.children[1].textContent,
      priority: taskElement.children[2].textContent,
      assignedTo: taskElement.children[3].textContent,
      deadline: taskElement.children[4].textContent,
    };
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }
}

/**
 * Changes the theme of the application.
 * @param {string} theme - The theme to apply ("standard", "light", or "darker").
 */
function changeTheme(theme) {
  localStorage.setItem("savedTheme", theme);
  savedTheme = theme;

  document.body.className = theme;

  document.querySelectorAll(".edit-btn").forEach((button) => {
    button.className = `edit-btn ${theme}-button`;
  });

  document.querySelectorAll(".delete-btn").forEach((button) => {
    button.className = `delete-btn ${theme}-button`;
  });
}

/**
 * Resets the task input form.
 */
function resetForm() {
  taskInput.value = "";
  taskDescription.value = "";
  taskPriority.value = "";
  taskAssignedTo.value = "";
  taskDeadline.value = "";

  isEditing = false;
  currentTaskElement = null;

  // Reset button text to "Add Task"
  addTaskBtn.textContent = "Add Task";
}

/**
 * Filters tasks based on the search bar input.
 * Searches based on task title and task assigned to
 */
function filterTasks() {
  const searchTerm = searchBar.value.trim().toLowerCase();
  const taskRows = Array.from(document.querySelectorAll(".task-list tr"));

  // Filter task rows based on the search term
  // using the functionality of Array.prototype.filter to go over each task rows.
  const filteredRows = taskRows.filter((row) => {
    const title = row.cells[0].textContent.toLowerCase();
    const isAssignedTo = row.cells[3].textContent.toLowerCase();
    return title.includes(searchTerm) || isAssignedTo.includes(searchTerm);
  });

  // Update display based on filtered results
  taskRows.forEach((row) => {
    if (filteredRows.includes(row)) {
      row.style.display = "table-row"; // Display matching rows
    } else {
      row.style.display = "none"; // Hide non-matching rows
    }
  });
}

/**
 * Updates the display of the number of active tasks.
 * @param {Array} tasks - The array of tasks.
 */
function resetTaskNumber(tasks) {
  numberItems.textContent = `Number of active tasks: ${tasks.length}`;
}

/**
 * Retrieves a color based on task priority.
 * @param {string} priority - The priority of the task ("high", "medium", "low").
 * @returns {string} The color code corresponding to the priority.
 */
function getColorByPriority(priority) {
  switch (priority) {
    case "high":
      return "#FFCCCB"; // Red for high priority
    case "medium":
      return "#ADFF2F"; // Gold for medium priority
    case "low":
      return "#FFFFFF"; // White for low priority
    default:
      return "#FFFFFF"; // Default to white if priority is undefined
  }
}

/**
 * Sets the background color of task rows based on their priority.
 */
function setColors() {
  const rows = document.querySelectorAll(".task-table tbody tr");
  rows.forEach((row) => {
    const priorityCell = row.querySelector("td:nth-child(3)");
    const priority = priorityCell.textContent.trim().toLowerCase();
    row.style.backgroundColor = getColorByPriority(priority);
  });
}
